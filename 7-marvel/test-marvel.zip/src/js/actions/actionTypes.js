/*
 * action types
 */

export const GET_MARVELS_SUCCESS = 'GET_MARVELS_SUCCESS'
export const GET_MARVEL_SUCCESS = 'GET_MARVEL_SUCCESS'